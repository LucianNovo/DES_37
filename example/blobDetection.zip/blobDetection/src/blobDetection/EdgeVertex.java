package blobDetection;

//==================================================
//class EdgeVertex
//==================================================
public class EdgeVertex
{
	public float x,y;
	public EdgeVertex(float x, float y){this.x=x;this.y=y;}
};